package com.gestion_student.gestion_student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
